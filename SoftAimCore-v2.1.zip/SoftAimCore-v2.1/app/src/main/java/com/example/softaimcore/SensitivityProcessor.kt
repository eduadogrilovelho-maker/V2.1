package com.example.softaimcore

import kotlin.math.abs
import kotlin.math.tanh

/** Pure mathematical transform. No system-wide input interception. */
class SensitivityProcessor {
    var intensity: Float = 0.60f
    var maxGain: Float = 2.0f
    var speedThreshold: Float = 0.25f // px/ms
    var sharpness: Float = 2.0f

    fun process(dy: Float, dtMs: Long): Float {
        if (dtMs <= 0L || dy == 0f) return dy
        val speed = abs(dy) / dtMs.toFloat()
        if (speed <= speedThreshold) return dy
        val normalized = tanh((speed - speedThreshold) * sharpness)
        val gain = (1f + intensity.coerceIn(0f, 1f) * normalized * 2f)
            .coerceIn(1f, maxGain.coerceIn(1f, 4f))
        return dy * gain
    }
}
