package com.example.softaimcore

import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.example.softaimcore.databinding.ActivityMainBinding
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var ui: ActivityMainBinding
    private val processor = SensitivityProcessor()
    private data class Finger(var x: Float, var y: Float, var time: Long)
    private val fingers = mutableMapOf<Int, Finger>()
    private var enabled = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = ActivityMainBinding.inflate(layoutInflater)
        setContentView(ui.root)
        ui.switchEnabled.setOnCheckedChangeListener { _, value -> enabled = value }
        ui.seekIntensity.setOnSeekBarChangeListener(seekListener { p ->
            processor.intensity = p / 100f
            ui.tvIntensity.text = "Intensidade: $p%"
        })
        ui.seekGain.setOnSeekBarChangeListener(seekListener { p ->
            processor.maxGain = 1f + p / 10f
            ui.tvGain.text = "Ganho máximo: %.1fx".format(Locale.US, processor.maxGain)
        })
        ui.testArea.setOnTouchListener { _, event -> handle(event); true }
    }

    private fun seekListener(onProgress: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = onProgress(progress)
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun handle(event: MotionEvent) {
        val startNs = SystemClock.elapsedRealtimeNanos()
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = event.actionIndex
                fingers[event.getPointerId(i)] = Finger(event.getX(i), event.getY(i), event.eventTime)
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val id = event.getPointerId(i)
                    val finger = fingers[id] ?: continue
                    val x = event.getX(i)
                    val y = event.getY(i)
                    val dx = x - finger.x
                    val dy = y - finger.y
                    val dt = event.eventTime - finger.time
                    val processed = if (enabled) processor.process(dy, dt) else dy
                    ui.tvRaw.text = "Vertical original: %.1f px".format(Locale.US, dy)
                    ui.tvProcessed.text = "Vertical processado: %.1f px".format(Locale.US, processed)
                    ui.tvHorizontal.text = "Horizontal original: %.1f px".format(Locale.US, dx)
                    finger.x = x; finger.y = y; finger.time = event.eventTime
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                fingers.remove(event.getPointerId(event.actionIndex))
            }
            MotionEvent.ACTION_CANCEL -> fingers.clear()
        }
        ui.tvFingers.text = "Dedos ativos: ${fingers.size}"
        val elapsedUs = (SystemClock.elapsedRealtimeNanos() - startNs) / 1000L
        ui.tvTiming.text = "Processamento + UI (aprox.): $elapsedUs µs"
    }
}
