package com.example.softaimcore

import org.junit.Assert.*
import org.junit.Test

class SensitivityProcessorTest {
    @Test fun stoppedFinger() { assertEquals(0f, SensitivityProcessor().process(0f, 10), 0f) }
    @Test fun invalidTime() { assertEquals(5f, SensitivityProcessor().process(5f, 0), 0f) }
    @Test fun slowDragUnchanged() { assertEquals(2f, SensitivityProcessor().process(2f, 20), 0f) }
    @Test fun fastDragAmplified() { assertTrue(SensitivityProcessor().process(10f, 10) > 10f) }
    @Test fun negativeDragPreservesDirection() { assertTrue(SensitivityProcessor().process(-10f, 10) < -10f) }
    @Test fun maxGainRespected() {
        val p = SensitivityProcessor().apply { intensity = 1f; maxGain = 1.5f }
        assertTrue(p.process(100f, 1) <= 150.0001f)
    }
    @Test fun disabledIntensityNoChange() {
        val p = SensitivityProcessor().apply { intensity = 0f }
        assertEquals(10f, p.process(10f, 10), 0f)
    }
}
