# Soft Aim Core v2.1 — Android demo

This is a standalone touch-processing demonstration. It **does not** change input in Free Fire or other apps, and does not use AccessibilityService or overlays.

## Build
Push this directory to a GitHub repository, open **Actions**, run **Build and test Android APK**, and download the `SoftAimCore-v2.1-debug` artifact. The workflow uses the official Gradle setup action (no unverified wrapper download).

Local: Android SDK 34, JDK 17, Gradle 8.5; run `gradle testDebugUnitTest assembleDebug`.

## Behavior
- Dynamic vertical gain: faster drags get amplified, slow drags remain at original displacement.
- Four independent pointer IDs tracked.
- Horizontal delta unchanged.
- ON/OFF switches demo processing.
- UI shows per-event raw and transformed deltas; timing is an approximate app-side event-handler duration, **not input-to-display latency**.

The demo does not inject transformed events into any other app. Tests cover only the pure mathematical processor. No real-device performance claims are made.
